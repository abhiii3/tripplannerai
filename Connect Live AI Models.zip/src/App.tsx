import React, { useState } from "react";
import { TripInputForm } from "./components/TripInputForm";
import {
  ItineraryDisplay,
  GeneratedItinerary,
} from "./components/ItineraryDisplay";
import { LoadingAnimation } from "./components/LoadingAnimation";
import { generateMockItinerary } from "./utils/mockData";
import { Toaster } from "./components/ui/sonner";

type AppState = "input" | "loading" | "results";

interface TripFormData {
  destination: string;
  startDate: string;
  endDate: string;
  travelers: string;
  tripType: string;
  workCommitments: string;
  preferences: string;
  budget: string;
}

export default function App() {
  const [appState, setAppState] = useState<AppState>("input");
  const [generatedItinerary, setGeneratedItinerary] =
    useState<GeneratedItinerary | null>(null);

  const handleGenerateItinerary = async (
    formData: TripFormData,
  ) => {
    setAppState("loading");

    // Simulate AI processing time
    await new Promise((resolve) => setTimeout(resolve, 3000));

    const itinerary = generateMockItinerary(formData);
    setGeneratedItinerary(itinerary);
    setAppState("results");
  };

  const handleNewTrip = () => {
    setAppState("input");
    setGeneratedItinerary(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="mb-2">Pro Trip-AI</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Transform your travel planning with AI. Get
            personalized itineraries that balance work
            commitments with unforgettable experiences.
          </p>
        </div>

        {/* Main Content */}
        {appState === "input" && (
          <TripInputForm
            onGenerate={handleGenerateItinerary}
            isGenerating={false}
          />
        )}

        {appState === "loading" && <LoadingAnimation />}

        {appState === "results" && generatedItinerary && (
          <ItineraryDisplay
            itinerary={generatedItinerary}
            onNewTrip={handleNewTrip}
          />
        )}
      </div>

      <Toaster />
    </div>
  );
}