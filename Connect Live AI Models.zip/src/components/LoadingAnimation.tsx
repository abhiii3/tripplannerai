import React from 'react';
import { Card, CardContent } from './ui/card';
import { MapPin, Plane, Calendar, Sparkles } from 'lucide-react';

export function LoadingAnimation() {
  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardContent className="py-12">
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="relative">
            <div className="w-16 h-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin"></div>
            <Sparkles className="w-6 h-6 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-primary" />
          </div>
          
          <div className="space-y-2">
            <h3 className="font-semibold">AI is crafting your perfect itinerary...</h3>
            <p className="text-sm text-muted-foreground">
              Analyzing destinations, scheduling activities, and optimizing your travel experience
            </p>
          </div>

          <div className="flex items-center justify-center space-x-8 text-muted-foreground">
            <div className="flex flex-col items-center space-y-2 animate-pulse">
              <MapPin className="w-5 h-5" />
              <span className="text-xs">Finding locations</span>
            </div>
            <div className="flex flex-col items-center space-y-2 animate-pulse" style={{ animationDelay: '0.5s' }}>
              <Calendar className="w-5 h-5" />
              <span className="text-xs">Scheduling events</span>
            </div>
            <div className="flex flex-col items-center space-y-2 animate-pulse" style={{ animationDelay: '1s' }}>
              <Plane className="w-5 h-5" />
              <span className="text-xs">Optimizing routes</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}