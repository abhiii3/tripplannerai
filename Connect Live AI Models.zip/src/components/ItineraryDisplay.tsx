import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  MapPin, 
  Clock, 
  Calendar, 
  Briefcase, 
  Camera, 
  Utensils, 
  Coffee,
  Copy,
  Share2,
  Download
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export interface ItineraryItem {
  id: string;
  time: string;
  title: string;
  location: string;
  type: 'meeting' | 'sightseeing' | 'dining' | 'transport' | 'accommodation';
  description: string;
  duration?: string;
  notes?: string;
}

export interface DayItinerary {
  date: string;
  dayOfWeek: string;
  items: ItineraryItem[];
}

export interface GeneratedItinerary {
  destination: string;
  startDate: string;
  endDate: string;
  totalDays: number;
  summary: string;
  days: DayItinerary[];
  tips: string[];
}

interface ItineraryDisplayProps {
  itinerary: GeneratedItinerary;
  onNewTrip: () => void;
}

export function ItineraryDisplay({ itinerary, onNewTrip }: ItineraryDisplayProps) {
  const handleCopy = async () => {
    try {
      const text = formatItineraryForCopy(itinerary);
      await navigator.clipboard.writeText(text);
      toast.success('Itinerary copied to clipboard!');
    } catch (error) {
      toast.error('Failed to copy itinerary');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${itinerary.destination} Trip Itinerary`,
          text: formatItineraryForCopy(itinerary),
        });
      } catch (error) {
        // User cancelled share or error occurred
        handleCopy(); // Fallback to copy
      }
    } else {
      handleCopy(); // Fallback for browsers without Web Share API
    }
  };

  const getTypeIcon = (type: ItineraryItem['type']) => {
    switch (type) {
      case 'meeting':
        return <Briefcase className="w-4 h-4" />;
      case 'sightseeing':
        return <Camera className="w-4 h-4" />;
      case 'dining':
        return <Utensils className="w-4 h-4" />;
      case 'transport':
        return <MapPin className="w-4 h-4" />;
      case 'accommodation':
        return <Coffee className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getTypeBadgeVariant = (type: ItineraryItem['type']) => {
    switch (type) {
      case 'meeting':
        return 'destructive';
      case 'sightseeing':
        return 'default';
      case 'dining':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-6 h-6 text-primary" />
                {itinerary.destination} Trip Plan
              </CardTitle>
              <p className="text-muted-foreground mt-2">
                {itinerary.startDate} - {itinerary.endDate} • {itinerary.totalDays} days
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleCopy}>
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button variant="outline" size="sm" disabled>
                <Download className="w-4 h-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">{itinerary.summary}</p>
        </CardContent>
      </Card>

      {/* Daily Itineraries */}
      {itinerary.days.map((day, dayIndex) => (
        <Card key={dayIndex}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              {day.dayOfWeek}, {day.date}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {day.items.map((item, itemIndex) => (
              <div key={item.id}>
                <div className="flex items-start gap-4">
                  <div className="flex items-center gap-2 min-w-[80px]">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{item.time}</span>
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {getTypeIcon(item.type)}
                          <h4 className="font-medium">{item.title}</h4>
                          <Badge variant={getTypeBadgeVariant(item.type)} className="text-xs">
                            {item.type}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">
                          <MapPin className="w-3 h-3 inline mr-1" />
                          {item.location}
                        </p>
                        <p className="text-sm">{item.description}</p>
                        {item.duration && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Duration: {item.duration}
                          </p>
                        )}
                        {item.notes && (
                          <p className="text-xs text-blue-600 mt-1">
                            💡 {item.notes}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                
                {itemIndex < day.items.length - 1 && (
                  <Separator className="mt-4" />
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}

      {/* Tips */}
      {itinerary.tips.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Pro Tips for Your Trip</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {itinerary.tips.map((tip, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-primary font-medium">•</span>
                  <span className="text-sm">{tip}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex justify-center">
        <Button onClick={onNewTrip} variant="outline">
          Plan Another Trip
        </Button>
      </div>
    </div>
  );
}

function formatItineraryForCopy(itinerary: GeneratedItinerary): string {
  let text = `${itinerary.destination} Trip Itinerary\n`;
  text += `${itinerary.startDate} - ${itinerary.endDate} • ${itinerary.totalDays} days\n\n`;
  text += `${itinerary.summary}\n\n`;

  itinerary.days.forEach((day) => {
    text += `${day.dayOfWeek}, ${day.date}\n`;
    text += '=' .repeat(30) + '\n';
    
    day.items.forEach((item) => {
      text += `${item.time} - ${item.title}\n`;
      text += `Location: ${item.location}\n`;
      text += `${item.description}\n`;
      if (item.duration) text += `Duration: ${item.duration}\n`;
      if (item.notes) text += `Note: ${item.notes}\n`;
      text += '\n';
    });
    
    text += '\n';
  });

  if (itinerary.tips.length > 0) {
    text += 'Pro Tips:\n';
    text += '-' .repeat(20) + '\n';
    itinerary.tips.forEach((tip) => {
      text += `• ${tip}\n`;
    });
  }

  return text;
}