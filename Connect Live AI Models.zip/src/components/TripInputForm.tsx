import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Calendar, MapPin, Users, Briefcase } from 'lucide-react';

interface TripFormData {
  destination: string;
  startDate: string;
  endDate: string;
  travelers: string;
  tripType: string;
  workCommitments: string;
  preferences: string;
  budget: string;
}

interface TripInputFormProps {
  onGenerate: (data: TripFormData) => void;
  isGenerating: boolean;
}

export function TripInputForm({ onGenerate, isGenerating }: TripInputFormProps) {
  const [formData, setFormData] = useState<TripFormData>({
    destination: '',
    startDate: '',
    endDate: '',
    travelers: '1',
    tripType: '',
    workCommitments: '',
    preferences: '',
    budget: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(formData);
  };

  const handleInputChange = (field: keyof TripFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const isFormValid = formData.destination && formData.startDate && formData.endDate && formData.tripType;

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-primary" />
          Plan Your Trip with AI
        </CardTitle>
        <p className="text-muted-foreground">
          Tell us about your travel plans and we'll create a personalized itinerary that balances work and leisure.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="destination">Destination</Label>
              <Input
                id="destination"
                placeholder="e.g., San Francisco, CA"
                value={formData.destination}
                onChange={(e) => handleInputChange('destination', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="travelers">Number of Travelers</Label>
              <Select value={formData.travelers} onValueChange={(value) => handleInputChange('travelers', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 person</SelectItem>
                  <SelectItem value="2">2 people</SelectItem>
                  <SelectItem value="3">3 people</SelectItem>
                  <SelectItem value="4">4 people</SelectItem>
                  <SelectItem value="5+">5+ people</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate" className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Start Date
              </Label>
              <Input
                id="startDate"
                type="date"
                value={formData.startDate}
                onChange={(e) => handleInputChange('startDate', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">End Date</Label>
              <Input
                id="endDate"
                type="date"
                value={formData.endDate}
                onChange={(e) => handleInputChange('endDate', e.target.value)}
                min={formData.startDate}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tripType">Trip Type</Label>
              <Select value={formData.tripType} onValueChange={(value) => handleInputChange('tripType', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select trip type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="business">Business Trip</SelectItem>
                  <SelectItem value="mixed">Business + Leisure</SelectItem>
                  <SelectItem value="leisure">Leisure Only</SelectItem>
                  <SelectItem value="conference">Conference/Event</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="budget">Budget Range</Label>
              <Select value={formData.budget} onValueChange={(value) => handleInputChange('budget', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select budget" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="budget">Budget ($0-100/day)</SelectItem>
                  <SelectItem value="mid">Mid-range ($100-300/day)</SelectItem>
                  <SelectItem value="luxury">Luxury ($300+/day)</SelectItem>
                  <SelectItem value="flexible">Flexible</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="workCommitments" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Work Commitments
            </Label>
            <Textarea
              id="workCommitments"
              placeholder="List any meetings, conferences, or work obligations..."
              value={formData.workCommitments}
              onChange={(e) => handleInputChange('workCommitments', e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="preferences" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Preferences & Interests
            </Label>
            <Textarea
              id="preferences"
              placeholder="Food preferences, activities you enjoy, places you'd like to visit, accessibility needs..."
              value={formData.preferences}
              onChange={(e) => handleInputChange('preferences', e.target.value)}
              rows={3}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full" 
            disabled={!isFormValid || isGenerating}
            size="lg"
          >
            {isGenerating ? 'Generating Your Itinerary...' : 'Generate AI Itinerary'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}