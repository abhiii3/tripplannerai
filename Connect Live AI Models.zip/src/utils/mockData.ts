import { GeneratedItinerary } from '../components/ItineraryDisplay';

export function generateMockItinerary(formData: any): GeneratedItinerary {
  const startDate = new Date(formData.startDate);
  const endDate = new Date(formData.endDate);
  const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  
  const mockItineraries: Record<string, Partial<GeneratedItinerary>> = {
    'san francisco': {
      summary: "A perfect blend of business meetings and Silicon Valley exploration. Your itinerary balances professional commitments with iconic San Francisco experiences, from tech tours to culinary adventures in the city by the bay.",
      tips: [
        "Book Uber/Lyft in advance during peak hours - SF traffic can be unpredictable",
        "Layer clothing! SF weather changes dramatically throughout the day",
        "Many restaurants don't take reservations - plan for walk-in waiting times",
        "Download offline maps - some areas have spotty cell service",
        "Bring comfortable walking shoes for the city's famous hills"
      ]
    },
    'new york': {
      summary: "Fast-paced NYC itinerary combining business efficiency with cultural highlights. Experience the city that never sleeps while maximizing your professional opportunities and iconic New York moments.",
      tips: [
        "Use the subway for faster travel - avoid taxis during rush hour",
        "Book Broadway shows and popular restaurants well in advance",
        "Walking is often faster than driving in Manhattan",
        "Keep important meetings in the same area to minimize travel time",
        "Download the Citibike app for quick short-distance trips"
      ]
    },
    'london': {
      summary: "A sophisticated London experience balancing work and pleasure. Navigate the city's rich history while maintaining your professional commitments, with time for traditional pubs and royal landmarks.",
      tips: [
        "Get an Oyster Card for easy public transport access",
        "Book afternoon tea reservations in advance",
        "Most pubs stop serving food at 9 PM",
        "Pack an umbrella - London weather is unpredictable",
        "Many museums offer free admission but special exhibitions require tickets"
      ]
    },
    'tokyo': {
      summary: "An immersive Tokyo adventure blending cutting-edge business culture with traditional Japanese experiences. Navigate this fascinating city while respecting local customs and maximizing both work and cultural opportunities.",
      tips: [
        "Get a JR Pass for unlimited train travel",
        "Learn basic bow etiquette for business meetings",
        "Many restaurants don't accept credit cards - carry cash",
        "Download Google Translate with camera feature for menus",
        "Avoid rush hour trains (7-9 AM, 5-7 PM) when possible"
      ]
    }
  };

  const cityKey = formData.destination.toLowerCase();
  const mockData = mockItineraries[cityKey] || mockItineraries['san francisco'];

  // Generate days
  const days = [];
  for (let i = 0; i < totalDays; i++) {
    const currentDate = new Date(startDate);
    currentDate.setDate(startDate.getDate() + i);
    
    const dayOfWeek = currentDate.toLocaleDateString('en-US', { weekday: 'long' });
    const dateString = currentDate.toLocaleDateString('en-US', { 
      month: 'long', 
      day: 'numeric',
      year: 'numeric'
    });

    days.push({
      date: dateString,
      dayOfWeek,
      items: generateDayItems(i, formData, cityKey)
    });
  }

  return {
    destination: formData.destination,
    startDate: startDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    endDate: endDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    totalDays,
    summary: mockData.summary || "A thoughtfully crafted itinerary balancing your professional commitments with local experiences.",
    days,
    tips: mockData.tips || [
      "Stay hydrated and take breaks between activities",
      "Keep important documents and emergency contacts handy",
      "Check local customs and etiquette before meetings"
    ]
  };
}

function generateDayItems(dayIndex: number, formData: any, cityKey: string) {
  const isFirstDay = dayIndex === 0;
  const isLastDay = dayIndex === 2; // Assuming 3-day trip for demo
  const isBusiness = formData.tripType === 'business' || formData.tripType === 'mixed';

  const cityActivities: Record<string, any> = {
    'san francisco': {
      meetings: [
        { title: "Tech Startup Pitch Meeting", location: "SOMA District", description: "Present quarterly innovations to potential investors" },
        { title: "Client Strategy Session", location: "Financial District", description: "Discuss Q4 partnership opportunities" }
      ],
      sightseeing: [
        { title: "Golden Gate Bridge", location: "Golden Gate Park", description: "Iconic SF landmark with stunning bay views" },
        { title: "Alcatraz Island Tour", location: "Pier 33", description: "Historic prison tour with audio guide" },
        { title: "Lombard Street", location: "Russian Hill", description: "Drive/walk the world's most crooked street" }
      ],
      dining: [
        { title: "Pier Market Seafood", location: "Fisherman's Wharf", description: "Fresh dungeness crab and clam chowder" },
        { title: "Mission District Tacos", location: "Mission District", description: "Authentic Mexican cuisine in vibrant neighborhood" }
      ]
    },
    'new york': {
      meetings: [
        { title: "Board Meeting", location: "Midtown Manhattan", description: "Quarterly review with stakeholders" },
        { title: "Networking Event", location: "Wall Street", description: "Finance industry mixer" }
      ],
      sightseeing: [
        { title: "Central Park", location: "Manhattan", description: "Stroll through America's most famous park" },
        { title: "9/11 Memorial", location: "Lower Manhattan", description: "Moving tribute to those lost" },
        { title: "Times Square", location: "Theater District", description: "Bright lights and Broadway energy" }
      ],
      dining: [
        { title: "Katz's Delicatessen", location: "Lower East Side", description: "Legendary pastrami sandwiches since 1888" },
        { title: "Little Italy Dinner", location: "Little Italy", description: "Traditional Italian-American cuisine" }
      ]
    }
  };

  const activities = cityActivities[cityKey] || cityActivities['san francisco'];
  const items = [];

  if (isFirstDay) {
    items.push({
      id: `arrival-${dayIndex}`,
      time: "10:00 AM",
      title: "Airport Arrival & Hotel Check-in",
      location: "Hotel Lobby",
      type: "accommodation" as const,
      description: "Arrive and settle in, freshen up for the day ahead",
      duration: "1 hour"
    });
  }

  if (isBusiness && dayIndex < 2) {
    const meeting = activities.meetings[dayIndex] || activities.meetings[0];
    items.push({
      id: `meeting-${dayIndex}`,
      time: isFirstDay ? "2:00 PM" : "9:00 AM",
      title: meeting.title,
      location: meeting.location,
      type: "meeting" as const,
      description: meeting.description,
      duration: "2 hours",
      notes: "Bring presentation materials and business cards"
    });
  }

  // Add sightseeing
  const sightseeing = activities.sightseeing[dayIndex] || activities.sightseeing[0];
  items.push({
    id: `sightseeing-${dayIndex}`,
    time: isBusiness ? "4:30 PM" : "11:00 AM",
    title: sightseeing.title,
    location: sightseeing.location,
    type: "sightseeing" as const,
    description: sightseeing.description,
    duration: "2-3 hours"
  });

  // Add dining
  const dining = activities.dining[dayIndex] || activities.dining[0];
  items.push({
    id: `dining-${dayIndex}`,
    time: "7:00 PM",
    title: dining.title,
    location: dining.location,
    type: "dining" as const,
    description: dining.description,
    duration: "1.5 hours",
    notes: formData.preferences.includes('vegetarian') ? "Vegetarian options available" : "Try the local specialties"
  });

  if (isLastDay) {
    items.push({
      id: `departure-${dayIndex}`,
      time: "11:00 AM",
      title: "Hotel Checkout & Airport Departure",
      location: "Hotel → Airport",
      type: "transport" as const,
      description: "Final preparations and journey home",
      duration: "2 hours",
      notes: "Allow extra time for airport security"
    });
  }

  return items;
}