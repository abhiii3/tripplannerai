
  # Connect Live AI Models

  This is a code bundle for Connect Live AI Models. The original project is available at https://www.figma.com/design/GuqcAqxBjQl5KRU0TqBA1V/Connect-Live-AI-Models.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  